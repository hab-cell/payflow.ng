import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, Volume2, CheckCheck } from "lucide-react";
import { formatTime } from "@/lib/format";

const filters = ["All", "Voice Alerts", "Transfers", "Bills", "Promos"];

export default function Notifications() {
  const navigate = useNavigate();
  const [all, setAll] = useState([]);
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const n = await base44.entities.Notification.list("-created_date", 100);
      setAll(n || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const markAllRead = async () => {
    const unread = all.filter((n) => !n.read);
    for (const n of unread) {
      await base44.entities.Notification.update(n.id, { read: true });
    }
    load();
  };

  const speak = (msg) => {
    try {
      const u = new SpeechSynthesisUtterance(msg);
      window.speechSynthesis.speak(u);
    } catch (_e) {}
  };

  const filtered = all.filter((n) => {
    if (filter === "All") return true;
    if (filter === "Voice Alerts") return n.notification_type === "voice_alert";
    if (filter === "Transfers") return n.notification_type === "debit" || n.notification_type === "credit";
    if (filter === "Bills") return n.notification_type === "bill";
    if (filter === "Promos") return n.notification_type === "promo";
    return true;
  });

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
            <ChevronLeft className="w-5 h-5 text-slate-600" />
          </button>
          <h1 className="text-lg font-bold text-slate-800">Notifications</h1>
        </div>
        <button onClick={markAllRead} className="text-xs text-[#008753] font-semibold flex items-center gap-1">
          <CheckCheck className="w-4 h-4" /> Mark all read
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-3 -mx-1 px-1">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={
              "px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition " +
              (filter === f ? "bg-[#008753] text-white" : "bg-white text-slate-500 border border-slate-100")
            }
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {loading ? (
          <p className="py-10 text-center text-sm text-slate-400">Loading...</p>
        ) : filtered.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate-400">No notifications</p>
        ) : (
          filtered.map((n) => (
            <div key={n.id} className={"bg-white rounded-2xl p-4 border " + (n.read ? "border-slate-100" : "border-emerald-200 bg-emerald-50/30")}>
              <div className="flex items-start gap-3">
                <span className={"w-9 h-9 rounded-full flex items-center justify-center shrink-0 " + (n.notification_type === "voice_alert" ? "bg-amber-100 text-amber-600" : n.notification_type === "credit" ? "bg-emerald-100 text-[#008753]" : "bg-slate-100 text-slate-500")}>
                  {n.notification_type === "voice_alert" ? <Volume2 className="w-4 h-4" /> : n.notification_type === "credit" ? "↓" : "↑"}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{n.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5 select-text">{n.message}</p>
                  <p className="text-[10px] text-slate-400 mt-1">{formatTime(n.created_date)}</p>
                  {n.notification_type === "voice_alert" && (
                    <button onClick={() => speak(n.message)} className="mt-2 text-xs text-amber-700 font-semibold flex items-center gap-1">
                      <Volume2 className="w-3.5 h-3.5" /> Replay Voice Message
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}