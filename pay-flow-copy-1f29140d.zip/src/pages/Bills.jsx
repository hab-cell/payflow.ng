import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { ChevronLeft, Smartphone, Wifi, Zap, Tv, Globe } from "lucide-react";
import PinModal from "@/components/wallet/PinModal";
import { formatNGN } from "@/lib/format";

const networks = ["MTN", "Glo", "Airtel", "9mobile"];
const discos = ["Ikeja Electric", "Eko Electric", "Abuja Electric", "Ibadan Electric", "Port Harcourt Electric"];
const cableProviders = ["DStv", "GOtv", "Startimes", "Showmax"];
const isps = ["Spectranet", "Smile", "Swift", "Starlink"];

const typeMeta = {
  airtime: { label: "Airtime", icon: Smartphone, field: "Phone Number", providers: networks },
  data: { label: "Data", icon: Wifi, field: "Phone Number", providers: networks },
  electricity: { label: "Electricity", icon: Zap, field: "Meter Number", providers: discos },
  cable: { label: "Cable TV", icon: Tv, field: "Smartcard Number", providers: cableProviders },
  internet: { label: "Internet", icon: Globe, field: "Account Number", providers: isps },
};

export default function Bills() {
  const navigate = useNavigate();
  const location = useLocation();
  const initialLabel = location.state?.type;
  const initialType =
    initialLabel === "Data" ? "data"
    : initialLabel === "Electricity" ? "electricity"
    : initialLabel === "Cable TV" ? "cable"
    : initialLabel === "Internet" ? "internet"
    : "airtime";

  const [type, setType] = useState(initialType);
  const [accountRef, setAccountRef] = useState("");
  const [provider, setProvider] = useState("");
  const [amount, setAmount] = useState("");
  const [pinOpen, setPinOpen] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [pinError, setPinError] = useState("");
  const [balance, setBalance] = useState(null);

  useEffect(() => {
    base44.functions.invoke("initAccount", {}).then((r) => setBalance(r.data.account));
  }, []);

  const meta = typeMeta[type];
  const Icon = meta.icon;

  const pay = async (pin) => {
    setProcessing(true);
    setPinError("");
    try {
      const res = await base44.functions.invoke("processBill", {
        bill_type: type,
        provider,
        meter_or_phone: accountRef,
        amount: Number(amount),
        pin,
        idempotency_key: "bill-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8),
      });
      if (res.data?.success) {
        setPinOpen(false);
        navigate("/");
      }
    } catch (e) {
      setPinError(e.response?.data?.error || "Payment failed. Try again.");
    } finally {
      setProcessing(false);
    }
  };

  const canProceed = accountRef.length >= 6 && provider && Number(amount) > 0;

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Pay Bills</h1>
      </div>

      {balance != null && (
        <p className="text-xs text-slate-400 mb-4">Wallet balance: <span className="font-semibold text-slate-600">{formatNGN(balance.available_balance)}</span></p>
      )}

      <div className="grid grid-cols-3 gap-2 mb-5">
        {Object.entries(typeMeta).map(([id, t]) => {
          const TIcon = t.icon;
          return (
            <button
              key={id}
              onClick={() => { setType(id); setProvider(""); }}
              className={"flex flex-col items-center gap-1.5 py-3 rounded-2xl border transition " + (type === id ? "bg-[#E8F8F2] border-[#008753] text-[#008753]" : "bg-white border-slate-100 text-slate-500")}
            >
              <TIcon className="w-5 h-5" />
              <span className="text-xs font-medium">{t.label}</span>
            </button>
          );
        })}
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>{meta.field}</Label>
          <Input
            inputMode="numeric"
            value={accountRef}
            onChange={(e) => setAccountRef(e.target.value.replace(/\D/g, ""))}
            placeholder={meta.field}
            className="h-12"
          />
        </div>

        <div className="space-y-2">
          <Label>Provider</Label>
          <Select value={provider} onValueChange={setProvider}>
            <SelectTrigger className="h-12 bg-white">
              <SelectValue placeholder={`Select ${type === "electricity" ? "disco" : type === "cable" ? "provider" : type === "internet" ? "ISP" : "network"}`} />
            </SelectTrigger>
            <SelectContent>
              {meta.providers.map((p) => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Amount (NGN)</Label>
          <Input
            inputMode="numeric"
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
            placeholder="0.00"
            className="h-12 text-lg"
          />
        </div>

        {(type === "airtime" || type === "data") && (
          <div className="flex gap-2">
            {["100", "200", "500", "1000"].map((a) => (
              <button key={a} onClick={() => setAmount(a)} className="flex-1 py-2 rounded-xl bg-white border border-slate-100 text-sm font-medium text-slate-600">
                ₦{a}
              </button>
            ))}
          </div>
        )}

        <Button
          onClick={() => { setPinError(""); setPinOpen(true); }}
          disabled={!canProceed}
          className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white"
        >
          <Icon className="w-4 h-4 mr-2" /> Pay {amount ? formatNGN(Number(amount)) : ""}
        </Button>
      </div>

      <PinModal open={pinOpen} onClose={() => setPinOpen(false)} onSubmit={pay} loading={processing} error={pinError} />
    </div>
  );
}