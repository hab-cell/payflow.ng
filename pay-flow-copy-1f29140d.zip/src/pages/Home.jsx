import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Bell, ArrowRight } from "lucide-react";
import BalanceCard from "@/components/wallet/BalanceCard";
import QuickActions from "@/components/wallet/QuickActions";
import TransactionItem from "@/components/wallet/TransactionItem";

export default function Home() {
  const navigate = useNavigate();
  const [account, setAccount] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const res = await base44.functions.invoke("initAccount", {});
      setAccount(res.data.account);
      const txs = await base44.entities.Transaction.list("-created_date", 5);
      setTransactions(txs || []);
      const notifs = await base44.entities.Notification.filter({ read: false });
      setUnread((notifs || []).length);
    } catch (_e) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const handler = () => load();
    window.addEventListener("payflow:refresh", handler);
    return () => window.removeEventListener("payflow:refresh", handler);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <div className="w-8 h-8 border-4 border-emerald-100 border-t-[#008753] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="px-5 pt-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="text-sm text-slate-400">Hello 👋</p>
          <p className="text-lg font-bold text-slate-800">Welcome back</p>
        </div>
        <button
          onClick={() => navigate("/notifications")}
          className="relative w-10 h-10 rounded-full bg-white border border-slate-100 flex items-center justify-center"
        >
          <Bell className="w-5 h-5 text-slate-600" />
          {unread > 0 && (
            <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </button>
      </div>

      <BalanceCard account={account} />

      <div className="mt-6">
        <p className="text-sm font-semibold text-slate-700 mb-3">Quick Actions</p>
        <QuickActions />
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm font-semibold text-slate-700">Recent Transactions</p>
          <button onClick={() => navigate("/transactions")} className="text-xs text-[#008753] font-semibold flex items-center gap-0.5">
            See all <ArrowRight className="w-3 h-3" />
          </button>
        </div>
        <div className="bg-white rounded-2xl px-4 divide-y divide-slate-50">
          {transactions.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-400">No transactions yet</p>
          ) : (
            transactions.map((t) => <TransactionItem key={t.id} tx={t} />)
          )}
        </div>
      </div>
    </div>
  );
}