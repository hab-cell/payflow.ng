import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { ChevronLeft, Search, Loader2, ShieldCheck, Volume2, Check } from "lucide-react";
import { formatNGN } from "@/lib/format";
import OtpModal from "@/components/wallet/OtpModal";
import PinModal from "@/components/wallet/PinModal";
import { toast } from "@/components/ui/use-toast";

const NIGERIAN_FIRST_NAMES = new Set([
  "chinedu","aisha","tunde","ngozi","bola","emeka","fatima","david","grace","yusuf",
  "chioma","samuel","hauwa","daniel","blessing","kunle","zainab","femi","maryam","obinna",
  "adaeze","ridwan","eunice","tope","halima","bello","eze","ahmed","nwosu","ibrahim",
  "adeleke","okon","mohammed","obi","olatunji","sani","kalu","adesanya","musa","ogun",
  "suleiman","nnamdi","abdulsalam","akpan","bakare","lawal","chidi","nkechi","taiwo","kemi",
  "segun","bisi","ebuka","nonso","ifeoma","uchenna","yemi","bukola","habiba","mariam",
  "fatimah","jumoke","yetunde","bimbo","damilola","ayomide","oluwaseun","tobiloba","nneka","ngozi"
]);

function isLocalName(name) {
  if (!name) return false;
  const first = String(name).trim().split(/\s+/)[0].toLowerCase();
  return NIGERIAN_FIRST_NAMES.has(first);
}

export default function SendMoney() {
  const navigate = useNavigate();
  const [banks, setBanks] = useState([]);
  const [bank, setBank] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [recipient, setRecipient] = useState(null);
  const [looking, setLooking] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [saveBeneficiary, setSaveBeneficiary] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [firstTime, setFirstTime] = useState(false);
  const [duplicate, setDuplicate] = useState(false);
  const [stage, setStage] = useState("recipient"); // recipient -> review -> otp -> pin -> done
  const [otpOpen, setOtpOpen] = useState(false);
  const [pinOpen, setPinOpen] = useState(false);
  const [pinError, setPinError] = useState("");
  const [processing, setProcessing] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [receipt, setReceipt] = useState(null);
  const [balance, setBalance] = useState(null);
  const [voiceMsg, setVoiceMsg] = useState("");
  const idemRef = useRef("");

  useEffect(() => {
    base44.entities.Bank.list().then((b) => setBanks(b || []));
    base44.entities.Beneficiary.list().then((b) => setBeneficiaries(b || []));
    base44.entities.Transaction.list("-created_date", 100).then((t) => setTransactions(t || []));
    base44.functions.invoke("initAccount", {}).then((r) => setBalance(r.data?.account?.available_balance ?? null)).catch(() => {});
  }, []);

  // Auto-lookup on 10 digits
  useEffect(() => {
    if (accountNumber.length === 10 && bank) {
      setLooking(true);
      setRecipient(null);
      setConfirmed(false);
      base44.functions
        .invoke("lookupRecipient", { bank_name: bank, account_number: accountNumber })
        .then((r) => setRecipient(r.data))
        .catch(() => setRecipient(null))
        .finally(() => setLooking(false));
    } else {
      setRecipient(null);
    }
  }, [accountNumber, bank]);

  const context = `${amount}|${bank}|${accountNumber}`;
  const speak = (text) => {
    try {
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.95;
      window.speechSynthesis.speak(u);
    } catch (_e) {}
  };

  const startReview = () => {
    if (balance != null && Number(amount) > Number(balance)) {
      toast({ title: "Insufficient balance", description: "This amount exceeds your wallet balance." });
      return;
    }
    setStage("review");
    // Stage 1 — two-stage voice alert: first-time recipient + duplicate detection
    const known = beneficiaries.some(
      (b) => b.account_number === accountNumber && b.bank_name === bank
    );
    const now = Date.now();
    const dupTx = transactions.some(
      (t) =>
        t.recipient_account_number === accountNumber &&
        t.direction === "debit" &&
        now - new Date(t.created_date).getTime() < 5 * 60 * 1000
    );
    setFirstTime(!known);
    setDuplicate(dupTx);
    const name = recipient?.account_name || "";
    const local = isLocalName(name);
    const msg = dupTx
      ? `Warning! You transferred to ${name} within the last 5 minutes. Please confirm this is not a duplicate transfer.`
      : local
        ? `Attention! You are about to transfer ${formatNGN(Number(amount || 0))}. You are about to transfer to the name below: ${name}. Please confirm this is your intended recipient.`
        : `Attention! You are about to transfer ${formatNGN(Number(amount || 0))} to a new recipient, ${name}. Please confirm this is your intended recipient.`;
    setVoiceMsg(msg);
    if (!known || dupTx) {
      setVoiceOpen(true);
      speak(msg);
      try {
        base44.entities.Notification.create({
          title: "Voice Alert",
          message: msg,
          notification_type: "voice_alert",
          read: false,
        });
      } catch (_e) {}
    }
  };

  const continueToOtp = () => {
    idemRef.current = "idem-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
    setStage("otp");
    setOtpOpen(true);
  };

  const onVerified = () => {
    setOtpOpen(false);
    setStage("pin");
    setPinOpen(true);
  };

  const completeTransfer = async (pin) => {
    setProcessing(true);
    setPinError("");
    try {
      const res = await base44.functions.invoke("processTransfer", {
        recipient_name: recipient.account_name,
        recipient_bank: bank,
        recipient_account_number: accountNumber,
        amount: Number(amount),
        description,
        pin,
        idempotency_key: idemRef.current,
      });
      if (res.data?.success) {
        if (saveBeneficiary && recipient) {
          try {
            const exists = beneficiaries.find((b) => b.account_number === accountNumber && b.bank_name === bank);
            if (!exists) {
              await base44.entities.Beneficiary.create({
                name: recipient.account_name,
                bank_name: bank,
                account_number: accountNumber,
              });
            }
          } catch (_e) {}
        }
        setPinOpen(false);
        setReceipt({
          reference: res.data.reference,
          amount: Number(amount),
          recipient_name: recipient.account_name,
          bank,
          accountNumber,
          description,
          date: new Date(),
        });
        setStage("done");
        toast({ title: "Money sent", description: `${formatNGN(Number(amount))} to ${recipient.account_name}` });
      }
    } catch (e) {
      setPinError(e.response?.data?.error || "Transfer failed. Try again.");
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => (stage === "recipient" ? navigate(-1) : setStage("recipient"))} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Send Money</h1>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-6">
        {["recipient", "review", "auth"].map((s, i) => (
          <div key={s} className="flex-1">
            <div className={"h-1.5 rounded-full " + (stage === "done" || stage === s || (stage === "otp" && s === "auth") || (stage === "pin" && s === "auth") || (stage === "review" && i <= 1) ? "bg-[#008753]" : "bg-slate-200")} />
          </div>
        ))}
      </div>

      {stage === "recipient" && (
        <div className="space-y-5">
          {beneficiaries.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
              {beneficiaries.map((b) => (
                <button
                  key={b.id}
                  onClick={() => { setBank(b.bank_name); setAccountNumber(b.account_number); }}
                  className="shrink-0 px-3 py-1.5 rounded-full bg-[#E8F8F2] text-[#065F46] text-xs font-medium border border-emerald-100"
                >
                  {b.name}
                </button>
              ))}
            </div>
          )}
          <div className="space-y-2">
            <Label>Select Bank</Label>
            <Select value={bank} onValueChange={setBank}>
              <SelectTrigger className="h-12 bg-white">
                <SelectValue placeholder="Choose bank" />
              </SelectTrigger>
              <SelectContent>
                {banks.map((b) => (
                  <SelectItem key={b.id} value={b.bank_name}>
                    {b.bank_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Account Number</Label>
            <Input
              inputMode="numeric"
              maxLength={10}
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
              placeholder="10-digit account number"
              className="h-12 text-lg tracking-wider"
            />
          </div>

          {looking && (
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Loader2 className="w-4 h-4 animate-spin" /> Verifying account...
            </div>
          )}

          {recipient && (
            <div className="bg-[#E8F8F2] rounded-2xl p-4 border border-emerald-100">
              <p className="text-xs text-emerald-700 font-medium mb-1">Account Name</p>
              <p className="text-lg font-bold text-[#065F46]">{recipient.account_name}</p>
              <p className="text-xs text-slate-500 mt-1">{recipient.bank_name} • {recipient.account_number}</p>
              <label className="flex items-center gap-2 mt-3 cursor-pointer">
                <Checkbox checked={confirmed} onCheckedChange={setConfirmed} />
                <span className="text-xs text-slate-600">
                  I confirm <b>{recipient.account_name}</b> is my intended recipient
                </span>
              </label>
            </div>
          )}

          <div className="space-y-2">
            <Label>Amount (NGN)</Label>
            <Input
              inputMode="numeric"
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))}
              placeholder="0.00"
              className="h-12 text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What's it for?" className="h-12" />
          </div>

          <Button
            onClick={startReview}
            disabled={!recipient || !confirmed || !amount || Number(amount) <= 0}
            className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white"
          >
            Continue
          </Button>
        </div>
      )}

      {stage === "review" && (
        <div className="space-y-5">
          <div className="bg-white rounded-2xl p-5 border border-slate-100 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Recipient</span>
              <span className="font-semibold text-slate-800">{recipient?.account_name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Bank</span>
              <span className="font-medium text-slate-700">{bank}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Account</span>
              <span className="font-medium text-slate-700 tracking-wider">{accountNumber}</span>
            </div>
            <div className="border-t border-slate-100 pt-3 flex justify-between">
              <span className="text-slate-400 text-sm">Amount</span>
              <span className="text-xl font-bold text-[#065F46]">{formatNGN(Number(amount))}</span>
            </div>
          </div>

          {firstTime && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-3">
              <Volume2 className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <p className="text-sm font-medium text-amber-800">Stage 1 — First-time recipient alert</p>
                <p className="text-xs text-amber-700 mt-0.5">Listen and confirm you're sending to the right person.</p>
                <button onClick={() => speak(voiceMsg)} className="text-xs text-amber-800 font-semibold mt-1 underline">
                  Replay voice
                </button>
              </div>
            </div>
          )}
          {duplicate && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex gap-3">
              <Volume2 className="w-5 h-5 text-red-600 shrink-0" />
              <div>
                <p className="text-sm font-medium text-red-700">Duplicate transfer warning</p>
                <p className="text-xs text-red-600 mt-0.5">You sent money to this recipient within the last 5 minutes. Confirm this isn't a mistake.</p>
                <button onClick={() => speak(voiceMsg)} className="text-xs text-red-700 font-semibold mt-1 underline">
                  Replay voice
                </button>
              </div>
            </div>
          )}

          <label className="flex items-center gap-2 cursor-pointer">
            <Checkbox checked={saveBeneficiary} onCheckedChange={setSaveBeneficiary} />
            <span className="text-xs text-slate-600">Save {recipient?.account_name} as beneficiary</span>
          </label>
          <Button onClick={continueToOtp} className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white">
            <ShieldCheck className="w-4 h-4 mr-2" /> Proceed to Authorization
          </Button>
        </div>
      )}

      {stage === "otp" && (
        <div className="text-center py-10">
          <p className="text-sm text-slate-500">Check your email for the authorization code.</p>
        </div>
      )}

      {stage === "pin" && (
        <div className="text-center py-10">
          <Check className="w-10 h-10 text-[#008753] mx-auto" />
          <p className="text-sm text-slate-500 mt-2">Verifying PIN...</p>
        </div>
      )}

      {stage === "done" && receipt && (
        <div className="space-y-5">
          <div className="flex flex-col items-center text-center pt-2">
            <div className="w-16 h-16 rounded-full bg-[#E8F8F2] flex items-center justify-center mb-3">
              <Check className="w-8 h-8 text-[#008753]" />
            </div>
            <p className="text-sm text-slate-400">Transfer successful</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{formatNGN(receipt.amount)}</p>
          </div>
          <div className="bg-white rounded-2xl p-5 border border-slate-100 space-y-3">
            <div className="flex justify-between text-sm"><span className="text-slate-400">Recipient</span><span className="font-semibold text-slate-800">{receipt.recipient_name}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-400">Bank</span><span className="font-medium text-slate-700">{receipt.bank}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-400">Account</span><span className="font-medium text-slate-700 tracking-wider">{receipt.accountNumber}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-400">Reference</span><span className="font-medium text-slate-700 tracking-wider">{receipt.reference}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-400">Date</span><span className="font-medium text-slate-700">{receipt.date.toLocaleString("en-NG")}</span></div>
            <div className="border-t border-slate-100 pt-3 flex justify-between text-sm"><span className="text-slate-400">Status</span><span className="font-semibold text-[#008753]">Completed</span></div>
          </div>
          <Button onClick={() => navigate("/")} className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white">
            Back to Dashboard
          </Button>
        </div>
      )}

      <OtpModal
        open={otpOpen}
        onClose={() => setOtpOpen(false)}
        context={context}
        amount={Number(amount)}
        recipientName={recipient?.account_name}
        onVerified={onVerified}
      />
      <PinModal
        open={pinOpen}
        onClose={() => setPinOpen(false)}
        onSubmit={completeTransfer}
        loading={processing}
        error={pinError}
      />
    </div>
  );
}