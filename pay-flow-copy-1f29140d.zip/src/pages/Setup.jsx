import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserPlus, Lock, Loader2, Phone, Calendar, User } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";

export default function Setup() {
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [dob, setDob] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    base44.auth
      .me()
      .then((u) => {
        if (u?.full_name) setFullName(u.full_name);
      })
      .catch(() => {});
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!fullName.trim()) return setError("Enter your full legal name");
    if (!phone.trim()) return setError("Enter your phone number");
    if (!dob) return setError("Enter your date of birth");
    if (!/^\d{4}$/.test(pin)) return setError("PIN must be 4 digits");
    if (pin !== confirmPin) return setError("PINs do not match");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("initAccount", {
        name: fullName.trim(),
        phone: phone.trim(),
        dob,
        pin,
      });
      if (res.data?.account) {
        window.location.href = "/";
      } else {
        setError("Could not set up your wallet. Try again.");
      }
    } catch (err) {
      setError(err.message || "Setup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout icon={UserPlus} title="Complete your setup" subtitle="Finish creating your PayFlow wallet">
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">{error}</div>
      )}
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Full Legal Name</Label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="name"
              placeholder="David Adeleke"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="pl-10 h-12"
              required
              autoFocus
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
              <Input
                id="phone"
                inputMode="tel"
                placeholder="0801 234 5678"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="pl-10 h-12"
                required
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="dob">Date of Birth</Label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
              <Input
                id="dob"
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className="pl-10 h-12"
                required
              />
            </div>
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="pin">4-digit Transaction PIN</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="pin"
              inputMode="numeric"
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
              className="pl-10 h-12 tracking-widest text-center text-lg"
              placeholder="••••"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirmPin">Confirm PIN</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="confirmPin"
              inputMode="numeric"
              type="password"
              maxLength={4}
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ""))}
              className="pl-10 h-12 tracking-widest text-center text-lg"
              placeholder="••••"
              required
            />
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Setting up wallet...
            </>
          ) : (
            "Create Wallet"
          )}
        </Button>
        <p className="text-xs text-muted-foreground text-center">
          Your 10-digit PayFlow account number and ₦50,000 wallet are created automatically.
        </p>
      </form>
    </AuthLayout>
  );
}