import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChevronLeft, CreditCard, Loader2, Check } from "lucide-react";
import { formatNGN } from "@/lib/format";

export default function AddMoney() {
  const navigate = useNavigate();
  const [amount, setAmount] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [name, setName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(null);

  const formatCard = (v) => {
    const d = v.replace(/\D/g, "").slice(0, 19);
    return d.replace(/(.{4})/g, "$1 ").trim();
  };
  const formatExpiry = (v) => {
    const d = v.replace(/\D/g, "").slice(0, 4);
    if (d.length <= 2) return d;
    return d.slice(0, 2) + "/" + d.slice(2);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (Number(amount) <= 0) return setError("Enter a valid amount");
    if (cardNumber.replace(/\s/g, "").length < 12) return setError("Enter a valid card number");
    if (!name.trim()) return setError("Enter the name on the card");
    if (!/^\d{2}\/\d{2}$/.test(expiry)) return setError("Enter expiry as MM/YY");
    if (!/^\d{3,4}$/.test(cvv)) return setError("Enter a valid CVV");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("addMoney", {
        amount: Number(amount),
        card_number: cardNumber.replace(/\s/g, ""),
        name_on_card: name.trim(),
        expiry,
        cvv,
      });
      if (res.data?.success) {
        setDone({ amount: Number(amount), reference: res.data.reference, new_balance: res.data.new_balance });
      } else {
        setError("Could not top up. Try again.");
      }
    } catch (e) {
      setError(e.response?.data?.error || "Could not top up. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Add Money</h1>
      </div>

      {done ? (
        <div className="space-y-5">
          <div className="flex flex-col items-center text-center pt-4">
            <div className="w-16 h-16 rounded-full bg-[#E8F8F2] flex items-center justify-center mb-3">
              <Check className="w-8 h-8 text-[#008753]" />
            </div>
            <p className="text-sm text-slate-400">Top-up successful</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{formatNGN(done.amount)}</p>
            <p className="text-xs text-slate-400 mt-1">New balance: {formatNGN(done.new_balance)}</p>
            <p className="text-xs text-slate-400">Ref: {done.reference}</p>
          </div>
          <Button onClick={() => navigate("/")} className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white">
            Back to Dashboard
          </Button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-100 space-y-4">
            <div className="flex items-center gap-2 text-[#065F46]">
              <CreditCard className="w-5 h-5" />
              <p className="text-sm font-semibold">Connect a bank card</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (NGN)</Label>
              <Input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))} placeholder="0.00" className="h-12 text-lg" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="card">Card Number</Label>
              <Input id="card" inputMode="numeric" value={cardNumber} onChange={(e) => setCardNumber(formatCard(e.target.value))} placeholder="0000 0000 0000 0000" className="h-12 tracking-wider" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Name on Card</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="DAVID ADELEKE" className="h-12 uppercase" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="exp">Expiry (MM/YY)</Label>
                <Input id="exp" inputMode="numeric" value={expiry} onChange={(e) => setExpiry(formatExpiry(e.target.value))} placeholder="MM/YY" className="h-12" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cvv">CVV</Label>
                <Input id="cvv" inputMode="numeric" type="password" maxLength={4} value={cvv} onChange={(e) => setCvv(e.target.value.replace(/\D/g, ""))} placeholder="•••" className="h-12" />
              </div>
            </div>
          </div>

          {error && <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm">{error}</div>}

          <Button type="submit" disabled={loading} className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white">
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...
              </>
            ) : (
              "Top Up" + (amount ? " " + formatNGN(Number(amount)) : "")
            )}
          </Button>
          <p className="text-xs text-slate-400 text-center">Card details are processed securely. We never store your full card number.</p>
        </form>
      )}
    </div>
  );
}