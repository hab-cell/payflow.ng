import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ChevronLeft, LogOut, Lock, Shield, CreditCard, Copy, Check, Trash2 } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { formatNGN } from "@/lib/format";
import ResetPinModal from "@/components/wallet/ResetPinModal";

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [account, setAccount] = useState(null);
  const [txs, setTxs] = useState([]);
  const [copied, setCopied] = useState(false);
  const [pinOpen, setPinOpen] = useState(false);
  const [oldPin, setOldPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [pinMsg, setPinMsg] = useState("");
  const [resetOpen, setResetOpen] = useState(false);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [bvn, setBvn] = useState("");
  const [nin, setNin] = useState("");
  const [nokName, setNokName] = useState("");
  const [nokPhone, setNokPhone] = useState("");
  const [upgrading, setUpgrading] = useState(false);
  const [upgradeMsg, setUpgradeMsg] = useState("");
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteMsg, setDeleteMsg] = useState("");

  const load = async () => {
    try {
      const res = await base44.functions.invoke("initAccount", {});
      setAccount(res.data.account);
      const t = await base44.entities.Transaction.list("-created_date", 100);
      setTxs(t || []);
    } catch (_e) {}
  };

  useEffect(() => {
    load();
  }, []);

  const todayTx = txs.filter((t) => {
    const d = new Date(t.created_date);
    const now = new Date();
    return d.toDateString() === now.toDateString() && t.direction === "debit";
  });
  const spentToday = todayTx.reduce((s, t) => s + Number(t.amount), 0);
  const tier = account?.tier || 1;
  const limit = tier === 3 ? 5000000 : tier === 2 ? 1000000 : 200000;

  const copyAcct = () => {
    if (!account) return;
    navigator.clipboard?.writeText(account.account_number);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const changePin = async () => {
    setPinMsg("");
    if (!/^\d{4}$/.test(oldPin)) {
      setPinMsg("Enter your current 4-digit PIN");
      return;
    }
    if (!/^\d{4}$/.test(newPin)) {
      setPinMsg("New PIN must be 4 digits");
      return;
    }
    try {
      await base44.functions.invoke("changePin", { old_pin: oldPin, new_pin: newPin });
      setPinMsg("PIN changed successfully");
      setOldPin("");
      setNewPin("");
    } catch (e) {
      setPinMsg(e.response?.data?.error || "Could not update PIN");
    }
  };

  const doLogout = () => {
    logout();
  };

  const deleteAccount = async () => {
    setDeleteMsg("");
    setDeleting(true);
    try {
      await base44.functions.invoke("deleteAccount", {});
      logout();
    } catch (e) {
      setDeleteMsg(e.response?.data?.error || "Could not delete account");
    } finally {
      setDeleting(false);
    }
  };

  const upgrade = async (target) => {
    setUpgradeMsg("");
    if (!/^\d{11}$/.test(bvn)) return setUpgradeMsg("BVN must be 11 digits");
    if (!/^\d{11}$/.test(nin)) return setUpgradeMsg("NIN must be 11 digits");
    if (target === 3) {
      if (!nokName.trim()) return setUpgradeMsg("Enter next of kin name");
      if (!nokPhone.trim()) return setUpgradeMsg("Enter next of kin phone");
    }
    setUpgrading(true);
    try {
      await base44.functions.invoke("upgradeTier", {
        target_tier: target,
        bvn: bvn.trim(),
        nin: nin.trim(),
        next_of_kin_name: nokName.trim(),
        next_of_kin_phone: nokPhone.trim(),
      });
      setUpgradeMsg("Account upgraded to Tier " + target);
      setBvn(""); setNin(""); setNokName(""); setNokPhone("");
      load();
    } catch (e) {
      setUpgradeMsg(e.response?.data?.error || "Upgrade failed");
    } finally {
      setUpgrading(false);
    }
  };

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate("/")} className="w-9 h-9 rounded-full bg-white border border-slate-100 flex items-center justify-center">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Profile</h1>
      </div>

      <div className="bg-white rounded-2xl p-5 border border-slate-100 flex items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-[#008753] text-white flex items-center justify-center text-lg font-bold">
          {(account?.name || user?.full_name || "PF").slice(0, 1).toUpperCase()}
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-slate-800 truncate">{account?.name || user?.full_name || "PayFlow User"}</p>
          <p className="text-xs text-slate-400 truncate">{user?.email}</p>
          <p className="text-xs text-slate-400">{user?.phone || "—"}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 border border-slate-100 mt-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400">PayFlow Account Number</p>
            <p className="text-lg font-bold tracking-wider text-slate-800">{account?.account_number || "—"}</p>
          </div>
          <button onClick={copyAcct} className="text-[#008753]">
            {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
          </button>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Daily Transfer Limit</span>
            <span>{formatNGN(spentToday)} / {formatNGN(limit)} • Tier 1</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-[#008753] rounded-full" style={{ width: `${Math.min(100, (spentToday / limit) * 100)}%` }} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 mt-4 p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-slate-800">Account Tier — Tier {tier}</p>
            <p className="text-xs text-slate-400 mt-0.5">Daily limit: {formatNGN(limit)}</p>
          </div>
          <Shield className="w-5 h-5 text-[#008753]" />
        </div>
        {tier < 3 ? (
          <Button onClick={() => setUpgradeOpen(true)} variant="outline" className="w-full h-10 mt-3 border-[#008753] text-[#008753] hover:bg-[#E8F8F2]">
            Upgrade Tier (KYC)
          </Button>
        ) : (
          <p className="text-xs text-[#008753] mt-2 font-medium">Fully verified — highest limits</p>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 mt-4 divide-y divide-slate-50">
        <button onClick={() => setPinOpen(true)} className="w-full flex items-center gap-3 p-4 text-left">
          <Lock className="w-5 h-5 text-slate-400" />
          <span className="text-sm text-slate-700 flex-1">Change Transaction PIN</span>
          <span className="text-xs text-slate-400">Change</span>
        </button>
        <div className="flex items-center gap-3 p-4">
          <Shield className="w-5 h-5 text-slate-400" />
          <span className="text-sm text-slate-700 flex-1">Security & Privacy</span>
          <span className="text-xs text-slate-400">Tier {tier}</span>
        </div>
        <div className="flex items-center gap-3 p-4">
          <CreditCard className="w-5 h-5 text-slate-400" />
          <span className="text-sm text-slate-700 flex-1">Linked Cards</span>
          <span className="text-xs text-slate-400">None</span>
        </div>
      </div>

      <Button onClick={doLogout} variant="outline" className="w-full h-12 mt-4 text-red-500 border-red-100 hover:bg-red-50">
        <LogOut className="w-4 h-4 mr-2" /> Log out
      </Button>

      <Button onClick={() => setDeleteOpen(true)} variant="outline" className="w-full h-12 mt-2 text-red-500 border-red-100 hover:bg-red-50">
        <Trash2 className="w-4 h-4 mr-2" /> Delete Account
      </Button>

      <p className="text-center text-[10px] text-slate-300 mt-4">PayFlow • Deposits insured by NDIC</p>

      <Dialog open={pinOpen} onOpenChange={setPinOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#065F46]">
              <Lock className="w-5 h-5" /> Change Transaction PIN
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Current PIN</Label>
              <Input inputMode="numeric" maxLength={4} type="password" value={oldPin} onChange={(e) => setOldPin(e.target.value.replace(/\D/g, ""))} className="h-11 tracking-widest" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">New 4-digit PIN</Label>
              <Input inputMode="numeric" maxLength={4} type="password" value={newPin} onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ""))} className="h-11 tracking-widest" />
            </div>
            {pinMsg && <p className="text-sm text-center text-slate-600">{pinMsg}</p>}
            <Button onClick={changePin} className="w-full h-11 bg-[#008753] hover:bg-[#065F46] text-white">Update PIN</Button>
            <button onClick={() => { setPinOpen(false); setResetOpen(true); }} className="w-full text-xs text-[#008753] font-semibold hover:underline">
              Forgot PIN? Reset via email
            </button>
          </div>
        </DialogContent>
      </Dialog>
      <ResetPinModal open={resetOpen} onClose={() => setResetOpen(false)} onDone={() => { setResetOpen(false); load(); }} />

      <Dialog open={upgradeOpen} onOpenChange={setUpgradeOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#065F46]">
              <Shield className="w-5 h-5" /> Upgrade Account Tier
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-slate-500">Verify your identity to raise your daily limit. Tier 2: BVN + NIN (₦1,000,000/day). Tier 3: + Next of Kin (₦5,000,000/day).</p>
            <div className="space-y-1.5">
              <Label className="text-xs">BVN (11 digits)</Label>
              <Input inputMode="numeric" maxLength={11} value={bvn} onChange={(e) => setBvn(e.target.value.replace(/\D/g, ""))} className="h-11 tracking-wider" placeholder="00000000000" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">NIN (11 digits)</Label>
              <Input inputMode="numeric" maxLength={11} value={nin} onChange={(e) => setNin(e.target.value.replace(/\D/g, ""))} className="h-11 tracking-wider" placeholder="00000000000" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Next of Kin Name (for Tier 3)</Label>
              <Input value={nokName} onChange={(e) => setNokName(e.target.value)} className="h-11" placeholder="Required for Tier 3" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Next of Kin Phone (for Tier 3)</Label>
              <Input inputMode="tel" value={nokPhone} onChange={(e) => setNokPhone(e.target.value)} className="h-11" placeholder="Required for Tier 3" />
            </div>
            {upgradeMsg && <p className="text-sm text-center text-slate-600">{upgradeMsg}</p>}
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={() => upgrade(2)} disabled={upgrading} className="h-11 bg-[#008753] hover:bg-[#065F46] text-white">Upgrade to Tier 2</Button>
              <Button onClick={() => upgrade(3)} disabled={upgrading} className="h-11 bg-[#065F46] hover:bg-[#06473a] text-white">Upgrade to Tier 3</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" /> Delete Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-slate-600">
              This permanently deletes your PayFlow wallet, transaction history, beneficiaries, and notifications. This action cannot be undone.
            </p>
            <p className="text-xs text-slate-500">
              Your login account remains, but you'll need to set up a fresh wallet to use PayFlow again.
            </p>
            {deleteMsg && <p className="text-sm text-red-500">{deleteMsg}</p>}
            <div className="flex gap-2">
              <Button onClick={() => setDeleteOpen(false)} variant="outline" className="flex-1 h-11" disabled={deleting}>
                Cancel
              </Button>
              <Button onClick={deleteAccount} className="flex-1 h-11 bg-red-500 hover:bg-red-600 text-white" disabled={deleting}>
                {deleting ? "Deleting..." : "Delete Permanently"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}