import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, Search } from "lucide-react";
import TransactionItem from "@/components/wallet/TransactionItem";

const filters = ["All", "Transfers", "Deposits", "Airtime/Data", "Bills"];

export default function Transactions() {
  const navigate = useNavigate();
  const [all, setAll] = useState([]);
  const [filter, setFilter] = useState("All");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const txs = await base44.entities.Transaction.list("-created_date", 100);
      setAll(txs || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = all.filter((t) => {
    const q = query.toLowerCase();
    const matchesQuery =
      !q ||
      (t.recipient_name || "").toLowerCase().includes(q) ||
      (t.reference || "").toLowerCase().includes(q) ||
      (t.description || "").toLowerCase().includes(q);
    const type = t.transaction_type;
    const matchesFilter =
      filter === "All" ||
      (filter === "Transfers" && type === "transfer") ||
      (filter === "Deposits" && type === "deposit") ||
      (filter === "Airtime/Data" && type === "airtime") ||
      (filter === "Bills" && type === "bill");
    return matchesQuery && matchesFilter;
  });

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-5">
        <button onClick={() => navigate(-1)} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Transactions</h1>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search recipient, reference..."
          className="w-full h-11 pl-10 pr-3 rounded-xl bg-white border border-slate-100 text-sm focus:border-[#008753] focus:outline-none"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-3 -mx-1 px-1">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={
              "px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition " +
              (filter === f ? "bg-[#008753] text-white" : "bg-white text-slate-500 border border-slate-100")
            }
          >
            {f}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl px-4 divide-y divide-slate-50">
        {loading ? (
          <p className="py-10 text-center text-sm text-slate-400">Loading...</p>
        ) : filtered.length === 0 ? (
          <p className="py-10 text-center text-sm text-slate-400">No transactions found</p>
        ) : (
          filtered.map((t) => <TransactionItem key={t.id} tx={t} />)
        )}
      </div>
    </div>
  );
}