import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, Copy, Check, Repeat, Share2, ShieldCheck } from "lucide-react";
import { formatNGN, formatTime } from "@/lib/format";

export default function TransactionDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [tx, setTx] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    base44.entities.Transaction
      .get(id)
      .then(setTx)
      .catch(() => setTx(null))
      .finally(() => setLoading(false));
  }, [id]);

  const copyRef = () => {
    if (!tx) return;
    navigator.clipboard?.writeText(tx.reference);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (loading) return <div className="flex justify-center pt-20"><div className="w-8 h-8 border-4 border-emerald-100 border-t-[#008753] rounded-full animate-spin" /></div>;
  if (!tx) return <p className="text-center text-slate-400 pt-20">Transaction not found</p>;

  const credit = tx.direction === "credit";

  return (
    <div className="px-5 pt-6 pb-10">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="w-11 h-11 rounded-full bg-white border border-slate-100 flex items-center justify-center select-none">
          <ChevronLeft className="w-5 h-5 text-slate-600" />
        </button>
        <h1 className="text-lg font-bold text-slate-800">Receipt</h1>
      </div>

      <div className="bg-white rounded-2xl p-5 border border-slate-100">
        <div className="flex flex-col items-center text-center pb-5 border-b border-slate-100">
          <div className={"w-14 h-14 rounded-full flex items-center justify-center " + (credit ? "bg-emerald-50 text-[#008753]" : "bg-slate-100 text-slate-500")}>
            {credit ? "↓" : "↑"}
          </div>
          <p className="text-xs text-slate-400 mt-2 uppercase tracking-wide">{credit ? "Credit" : "Debit"} • {tx.transaction_type}</p>
          <p className={"text-3xl font-bold mt-1 " + (credit ? "text-[#008753]" : "text-slate-800")}>
            {credit ? "+" : "-"}{formatNGN(tx.amount)}
          </p>
          <p className="text-xs text-slate-400 mt-1">{formatTime(tx.created_date)}</p>
        </div>

        <div className="py-4 space-y-3 text-sm">
          <Row label="Recipient" value={tx.recipient_name} />
          <Row label="Bank" value={tx.recipient_bank} />
          <Row label="Account" value={tx.recipient_account_number} mono />
          <Row label="Description" value={tx.description || "—"} />
          <Row label="Status" value={<span className="text-[#008753] font-medium capitalize">{tx.status}</span>} />
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Reference</span>
            <button onClick={copyRef} className="flex items-center gap-1.5 text-slate-700 font-medium">
              <span className="font-mono text-xs">{tx.reference}</span>
              {copied ? <Check className="w-3.5 h-3.5 text-[#008753]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 py-2 border-t border-slate-100">
          <ShieldCheck className="w-3 h-3" /> Deposits insured by NDIC
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-4">
        <button onClick={() => navigate("/send")} className="flex items-center justify-center gap-2 h-11 rounded-xl bg-white border border-slate-100 text-sm font-medium text-slate-700">
          <Repeat className="w-4 h-4" /> Repeat Transfer
        </button>
        <button
          onClick={() => {
            if (navigator.share) navigator.share({ title: "PayFlow Receipt", text: `Receipt ${tx.reference} - ${formatNGN(tx.amount)}` });
          }}
          className="flex items-center justify-center gap-2 h-11 rounded-xl bg-white border border-slate-100 text-sm font-medium text-slate-700"
        >
          <Share2 className="w-4 h-4" /> Share
        </button>
      </div>
    </div>
  );
}

function Row({ label, value, mono }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-400">{label}</span>
      <span className={"text-slate-700 font-medium select-text " + (mono ? "tracking-wider" : "")}>{value}</span>
    </div>
  );
}