import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Image } from "@/components/ui/image";
import { Button } from "@/components/ui/button";
import { Send, Zap, ShieldCheck, BarChart3, ChevronRight } from "lucide-react";
import { APP_ICON as ICON } from "@/lib/appIcon";

const features = [
  {
    icon: Send,
    title: "Instant Transfers",
    text: "Send money to any Nigerian bank account in seconds. No delays, no stress.",
    color: "#008753",
  },
  {
    icon: Zap,
    title: "Bills & Airtime",
    text: "Pay electricity, cable, data and airtime — all from one wallet.",
    color: "#0EA5E9",
  },
  {
    icon: ShieldCheck,
    title: "Bank-Grade Security",
    text: "Transaction PIN, OTP verification and NDIC-insured deposits keep your money safe.",
    color: "#F59E0B",
  },
  {
    icon: BarChart3,
    title: "Track Spending",
    text: "Real-time balance and full transaction history right at your fingertips.",
    color: "#8B5CF6",
  },
];

export default function Welcome() {
  const [i, setI] = useState(0);
  const navigate = useNavigate();
  const last = i === features.length - 1;

  const finish = () => {
    localStorage.setItem("payflow_onboarded", "1");
    navigate("/login", { replace: true });
  };

  const next = () => (last ? finish() : setI(i + 1));
  const f = features[i];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F0FDF4] to-white flex flex-col">
      <div className="flex items-center justify-between px-6 pt-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl overflow-hidden">
            <Image src={ICON} alt="PayFlow" className="w-full h-full" fittingType="fill" />
          </div>
          <span className="font-bold text-[#065F46]">PayFlow</span>
        </div>
        {!last && (
          <button onClick={finish} className="text-sm text-slate-500 font-medium">
            Skip
          </button>
        )}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.35 }}
            className="flex flex-col items-center"
          >
            <div
              className="w-28 h-28 rounded-[2rem] flex items-center justify-center shadow-lg mb-8"
              style={{ background: f.color + "1A" }}
            >
              <f.icon className="w-14 h-14" style={{ color: f.color }} strokeWidth={1.6} />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-3">{f.title}</h2>
            <p className="text-slate-500 text-base max-w-xs">{f.text}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="px-8 pb-10">
        <div className="flex justify-center gap-2 mb-6">
          {features.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setI(idx)}
              className={
                "h-2 rounded-full transition-all " +
                (idx === i ? "w-6 bg-[#008753]" : "w-2 bg-slate-300")
              }
            />
          ))}
        </div>
        <Button
          onClick={next}
          className="w-full h-14 bg-[#008753] hover:bg-[#065F46] text-white text-base font-semibold rounded-xl"
        >
          {last ? "Get Started" : "Continue"}
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}