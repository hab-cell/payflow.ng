import { useRef, useState } from "react";
import { Loader2 } from "lucide-react";

const THRESHOLD = 70;

export default function PullToRefresh({ onRefresh, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(null);
  const active = useRef(false);

  const onTouchStart = (e) => {
    if (window.scrollY <= 0) {
      startY.current = e.touches[0].clientY;
      active.current = true;
    } else {
      startY.current = null;
      active.current = false;
    }
  };

  const onTouchMove = (e) => {
    if (!active.current || startY.current == null || refreshing) return;
    const dy = e.touches[0].clientY - startY.current;
    if (dy > 0) {
      setPull(Math.min(dy * 0.5, 100));
    }
  };

  const onTouchEnd = async () => {
    const triggered = pull >= THRESHOLD && !refreshing;
    active.current = false;
    startY.current = null;
    if (triggered) {
      setRefreshing(true);
      setPull(THRESHOLD);
      try {
        await onRefresh?.();
      } finally {
        setRefreshing(false);
        setPull(0);
      }
    } else {
      setPull(0);
    }
  };

  const height = refreshing ? THRESHOLD : pull;

  return (
    <div
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      className="relative"
    >
      <div
        className="flex items-center justify-center overflow-hidden transition-all duration-150"
        style={{ height }}
      >
        <Loader2
          className={
            "w-5 h-5 text-[#008753] " + (refreshing ? "animate-spin" : "")
          }
        />
      </div>
      {children}
    </div>
  );
}