import { useState } from "react";
import { Eye, EyeOff, Copy, Check, Plus, ArrowUpRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { formatNGN } from "@/lib/format";

export default function BalanceCard({ account }) {
  const [show, setShow] = useState(true);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();

  const copy = () => {
    if (!account) return;
    navigator.clipboard?.writeText(account.account_number);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="rounded-3xl p-5 text-white shadow-lg shadow-emerald-900/20 select-none" style={{ background: "linear-gradient(135deg,#008753 0%,#065F46 100%)" }}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-emerald-100/80 text-xs font-medium">PayFlow Wallet</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-2xl font-bold tracking-tight">
              {show ? formatNGN(account?.available_balance ?? 0) : "₦ • • • • • •"}
            </span>
            <button onClick={() => setShow((s) => !s)} className="text-emerald-100/80 hover:text-white">
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <div className="text-[10px] font-semibold bg-white/15 px-2.5 py-1 rounded-full">Tier {account?.tier || 1}</div>
      </div>

      <div className="flex gap-2 mt-5">
        <button
          onClick={() => navigate("/add-money")}
          className="flex-1 bg-white/15 hover:bg-white/25 transition rounded-xl py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Add Money
        </button>
        <button
          onClick={() => navigate("/send")}
          className="flex-1 bg-white text-[#065F46] hover:bg-emerald-50 transition rounded-xl py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5"
        >
          <ArrowUpRight className="w-4 h-4" /> Transfer
        </button>
      </div>

      <div className="mt-4 flex items-center justify-between bg-white/10 rounded-xl px-3 py-2.5">
        <div className="min-w-0">
          <p className="text-[10px] text-emerald-100/70">PayFlow • Savings • NDIC Insured</p>
          <p className="text-sm font-semibold tracking-wider truncate">
            {account?.account_number || "----------"}
          </p>
        </div>
        <button onClick={copy} className="text-emerald-50 hover:text-white shrink-0">
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}