import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Image } from "@/components/ui/image";
import { base44 } from "@/api/base44Client";
import { APP_ICON as ICON } from "@/lib/appIcon";

export default function Splash() {
  const [show, setShow] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const t = setTimeout(async () => {
      try {
        const authed = await base44.auth.isAuthenticated();
        if (!authed && !localStorage.getItem("payflow_onboarded")) {
          navigate("/welcome", { replace: true });
        }
      } catch (_e) {}
      setShow(false);
    }, 1900);
    return () => clearTimeout(t);
  }, [navigate]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-b from-[#008753] to-[#065F46]"
        >
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl ring-4 ring-white/20"
          >
            <Image src={ICON} alt="PayFlow" className="w-full h-full" fittingType="fill" />
          </motion.div>
          <motion.h1
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.25, duration: 0.5 }}
            className="mt-5 text-white text-3xl font-bold tracking-tight"
          >
            PayFlow
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-white/80 text-sm mt-1"
          >
            Your money, in flow.
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="absolute bottom-10 flex items-center gap-2 text-white/70 text-xs"
          >
            <span className="w-2 h-2 rounded-full bg-white/70 animate-pulse" />
            Deposits insured by NDIC
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}