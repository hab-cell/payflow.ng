import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, ShieldCheck } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function OtpModal({ open, onClose, context, amount, recipientName, onVerified }) {
  const [code, setCode] = useState("");
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState("");
  const [resendIn, setResendIn] = useState(0);

  const send = async () => {
    setSending(true);
    setError("");
    try {
      await base44.functions.invoke("sendTransferOtp", { context, amount, recipient_name: recipientName });
      setResendIn(60);
    } catch (e) {
      setError(e.response?.data?.error || "Unable to send the verification email right now.");
    } finally {
      setSending(false);
    }
  };

  useEffect(() => {
    if (open) {
      setCode("");
      setError("");
      send();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const verify = async () => {
    setVerifying(true);
    setError("");
    try {
      const res = await base44.functions.invoke("verifyTransferOtp", { code, context });
      if (res.data?.verified) onVerified();
    } catch (e) {
      setError(e.response?.data?.error || "Incorrect code");
    } finally {
      setVerifying(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#065F46]">
            <ShieldCheck className="w-5 h-5" /> Authorize Transfer
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-slate-500 -mt-1">
          We sent a 6-digit code to your email to authorize this transfer.
        </p>
        <input
          inputMode="numeric"
          maxLength={6}
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
          placeholder="------"
          className="w-full text-center text-2xl tracking-[0.5em] font-bold py-3 rounded-xl border border-slate-200 focus:border-[#008753] focus:outline-none"
        />
        {error && <p className="text-sm text-red-500 text-center">{error}</p>}
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">
            {resendIn > 0 ? `Resend code in 00:${String(resendIn).padStart(2, "0")}` : "Didn't get it?"}
          </span>
          <button
            disabled={resendIn > 0 || sending}
            onClick={send}
            className="text-[#008753] font-semibold disabled:opacity-40"
          >
            {sending ? "Sending..." : "Resend Code"}
          </button>
        </div>
        <Button
          onClick={verify}
          disabled={code.length !== 6 || verifying}
          className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white"
        >
          {verifying ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
          Verify Code & Continue
        </Button>
      </DialogContent>
    </Dialog>
  );
}