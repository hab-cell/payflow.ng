import { NavLink } from "react-router-dom";
import { Home, ArrowUpRight, Clock, Bell, User } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/send", label: "Send", icon: ArrowUpRight },
  { to: "/transactions", label: "History", icon: Clock },
  { to: "/notifications", label: "Alerts", icon: Bell },
  { to: "/profile", label: "Profile", icon: User },
];

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-[#E2E8F0] z-40 select-none pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-stretch justify-between px-2 py-1.5">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <NavLink
              key={it.to}
              to={it.to}
              end={it.end}
              className={({ isActive }) =>
                "flex flex-col items-center justify-center gap-0.5 flex-1 py-1.5 rounded-xl transition-colors " +
                (isActive ? "text-[#008753]" : "text-slate-400")
              }
            >
              <Icon className="w-5 h-5" strokeWidth={2.2} />
              <span className="text-[10px] font-medium">{it.label}</span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}