import { useNavigate } from "react-router-dom";
import { Smartphone, Wifi, Zap, Tv, Globe, Users } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const actions = [
  { label: "Airtime", icon: Smartphone },
  { label: "Data", icon: Wifi },
  { label: "Electricity", icon: Zap },
  { label: "Cable TV", icon: Tv },
  { label: "Internet", icon: Globe },
  { label: "Beneficiaries", icon: Users },
];

export default function QuickActions() {
  const navigate = useNavigate();
  const { toast } = useToast();
  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((a) => {
        const Icon = a.icon;
        return (
          <button
            key={a.label}
            onClick={() =>
              a.label === "Beneficiaries"
                ? navigate("/send")
                : navigate("/bills", { state: { type: a.label } })
            }
            className="flex flex-col items-center gap-1.5 group select-none"
          >
            <span className="w-12 h-12 rounded-2xl bg-[#E8F8F2] text-[#008753] flex items-center justify-center group-hover:bg-[#008753] group-hover:text-white transition-colors">
              <Icon className="w-5 h-5" />
            </span>
            <span className="text-[11px] font-medium text-slate-600">{a.label}</span>
          </button>
        );
      })}
    </div>
  );
}