import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, KeyRound } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function ResetPinModal({ open, onClose, onDone }) {
  const [stage, setStage] = useState("send"); // send -> reset
  const [code, setCode] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  useEffect(() => {
    if (open) {
      setStage("send");
      setCode("");
      setNewPin("");
      setConfirmPin("");
      setError("");
      setInfo("");
    }
  }, [open]);

  const send = async () => {
    setLoading(true);
    setError("");
    try {
      await base44.functions.invoke("sendPinResetOtp", {});
      setInfo("A 6-digit code was sent to your email.");
      setStage("reset");
    } catch (e) {
      setError(e.response?.data?.error || "Unable to send the verification email right now.");
    } finally {
      setLoading(false);
    }
  };

  const reset = async () => {
    setError("");
    if (newPin !== confirmPin) return setError("PINs do not match");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("resetPin", { code, new_pin: newPin });
      if (res.data?.success) {
        onDone();
      }
    } catch (e) {
      setError(e.response?.data?.error || "Reset failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#065F46]">
            <KeyRound className="w-5 h-5" /> Reset Transaction PIN
          </DialogTitle>
        </DialogHeader>

        {stage === "send" ? (
          <div className="space-y-3">
            <p className="text-sm text-slate-500">
              We'll email a verification code to confirm it's you, then you can set a new 4-digit PIN.
            </p>
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button onClick={send} disabled={loading} className="w-full h-11 bg-[#008753] hover:bg-[#065F46] text-white">
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Send Verification Code
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {info && <p className="text-xs text-emerald-700 bg-emerald-50 rounded-lg p-2">{info}</p>}
            <div className="space-y-1.5">
              <Label className="text-xs">6-digit code</Label>
              <Input
                inputMode="numeric"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                className="h-11 tracking-widest text-center"
                placeholder="------"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">New 4-digit PIN</Label>
              <Input
                inputMode="numeric"
                type="password"
                maxLength={4}
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ""))}
                className="h-11 tracking-widest text-center"
                placeholder="••••"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Confirm new PIN</Label>
              <Input
                inputMode="numeric"
                type="password"
                maxLength={4}
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ""))}
                className="h-11 tracking-widest text-center"
                placeholder="••••"
              />
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button
              onClick={reset}
              disabled={loading || code.length !== 6 || newPin.length !== 4}
              className="w-full h-11 bg-[#008753] hover:bg-[#065F46] text-white"
            >
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Reset PIN
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}