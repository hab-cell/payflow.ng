import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Lock, KeyRound } from "lucide-react";
import ResetPinModal from "@/components/wallet/ResetPinModal";
import { toast } from "@/components/ui/use-toast";

const MAX_ATTEMPTS = 3;

export default function PinModal({ open, onClose, onSubmit, loading, error }) {
  const [pin, setPin] = useState("");
  const [failed, setFailed] = useState(0);
  const [locked, setLocked] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);

  // Reset state every time the modal is (re)opened
  useEffect(() => {
    if (open) {
      setPin("");
      setFailed(0);
      setLocked(false);
      setResetOpen(false);
    }
  }, [open]);

  // Count only PIN-related failures coming back from the server.
  // The parent clears the error to "" before each attempt, so each
  // transition to a non-empty PIN error represents one fresh failure.
  useEffect(() => {
    if (!error) return;
    if (/pin/i.test(error)) {
      setPin("");
      setFailed((n) => {
        const next = n + 1;
        if (next >= MAX_ATTEMPTS) setLocked(true);
        return next;
      });
    }
  }, [error]);

  const submit = () => {
    if (pin.length === 4) onSubmit(pin);
  };

  const cancelReset = () => {
    setLocked(false);
    setFailed(0);
    setPin("");
  };

  const onResetDone = () => {
    setResetOpen(false);
    setLocked(false);
    setFailed(0);
    setPin("");
    toast({
      title: "PIN changed",
      description: "Your new PIN is set. You can retry your transaction.",
    });
  };

  return (
    <>
      <Dialog open={open && !resetOpen} onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#065F46]">
              <Lock className="w-5 h-5" /> Enter Transaction PIN
            </DialogTitle>
          </DialogHeader>

          {locked ? (
            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                You entered the wrong PIN {MAX_ATTEMPTS} times. Forgotten your PIN?
                You can set a new one after confirming your email.
              </p>
              <Button
                onClick={() => setResetOpen(true)}
                className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white"
              >
                <KeyRound className="w-4 h-4 mr-2" /> Reset PIN via Email
              </Button>
              <Button onClick={cancelReset} variant="outline" className="w-full h-12">
                Cancel — I remember my PIN
              </Button>
            </div>
          ) : (
            <>
              <p className="text-sm text-slate-500 -mt-1">
                Enter your 4-digit PIN to complete this transaction.
              </p>
              <input
                inputMode="numeric"
                maxLength={4}
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                placeholder="••••"
                className="w-full text-center text-3xl tracking-[0.5em] font-bold py-3 rounded-xl border border-slate-200 focus:border-[#008753] focus:outline-none"
              />
              {error && <p className="text-sm text-red-500 text-center">{error}</p>}
              {failed > 0 && failed < MAX_ATTEMPTS && (
                <p className="text-xs text-amber-600 text-center">
                  Incorrect PIN. {MAX_ATTEMPTS - failed} attempt
                  {MAX_ATTEMPTS - failed === 1 ? "" : "s"} left before reset is required.
                </p>
              )}
              <Button
                onClick={submit}
                disabled={pin.length !== 4 || loading}
                className="w-full h-12 bg-[#008753] hover:bg-[#065F46] text-white"
              >
                {loading ? "Processing..." : "Confirm"}
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>

      <ResetPinModal
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        onDone={onResetDone}
      />
    </>
  );
}