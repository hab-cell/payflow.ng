import { useNavigate } from "react-router-dom";
import { ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { formatNGN, formatTime, initials } from "@/lib/format";

export default function TransactionItem({ tx }) {
  const navigate = useNavigate();
  const credit = tx.direction === "credit";
  return (
    <button
      onClick={() => navigate(`/transactions/${tx.id}`)}
      className="w-full flex items-center gap-3 py-3 text-left select-none"
    >
      <span
        className={
          "w-10 h-10 rounded-full flex items-center justify-center text-xs font-bold shrink-0 " +
          (credit ? "bg-emerald-50 text-[#008753]" : "bg-slate-100 text-slate-500")
        }
      >
        {initials(tx.recipient_name)}
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-800 truncate">{tx.recipient_name}</p>
        <p className="text-xs text-slate-400">{formatTime(tx.created_date)}</p>
      </div>
      <div className="text-right">
        <p className={"text-sm font-semibold " + (credit ? "text-[#008753]" : "text-slate-800")}>
          {credit ? "+" : "-"}
          {formatNGN(tx.amount)}
        </p>
        <p className="text-[10px] text-slate-400 uppercase tracking-wide">{tx.transaction_type}</p>
      </div>
    </button>
  );
}