import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import BottomNav from "@/components/wallet/BottomNav";
import PullToRefresh from "@/components/wallet/PullToRefresh";

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.functions.invoke("initAccount", {});
        if (res.data?.needs_setup && location.pathname !== "/setup") {
          navigate("/setup", { replace: true });
          return;
        }
      } catch (_e) {
        // ignore — child pages handle their own loading
      }
      setReady(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const speak = (text) => {
      try {
        const u = new SpeechSynthesisUtterance(text);
        u.rate = 0.98;
        window.speechSynthesis.speak(u);
      } catch (_e) {}
    };
    const unsub = base44.entities.Notification.subscribe((event) => {
      if (event?.type === "create" && event?.data?.title === "Credit Alert") {
        const msg = event.data.message || "";
        const m = msg.match(/\u20A6([\d,]+)/);
        speak(m ? `You just received a payment of ${m[1]} Naira in your PayFlow account` : "You just received a payment in your PayFlow account");
      }
    });
    return () => {
      if (typeof unsub === "function") unsub();
    };
  }, []);

  const refresh = () => {
    window.dispatchEvent(new CustomEvent("payflow:refresh"));
  };

  if (!ready) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] max-w-md mx-auto flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-emerald-100 border-t-[#008753] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] max-w-md mx-auto relative flex flex-col shadow-sm pt-[env(safe-area-inset-top)]">
      <div className="flex-1 pb-24 overscroll-none">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            <PullToRefresh onRefresh={refresh}>
              <Outlet />
            </PullToRefresh>
          </motion.div>
        </AnimatePresence>
      </div>
      <BottomNav />
    </div>
  );
}