export function genAccountNumber() {
  let n = "";
  for (let i = 0; i < 10; i++) n += Math.floor(Math.random() * 10);
  return n;
}

export function genReference() {
  const s = Math.random().toString(36).slice(2, 10).toUpperCase();
  return "PF-TRF-" + s;
}

export function randomSalt() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export async function sha256hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function genOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}