import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { sha256hex } from "../../shared/wallet.ts";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const code = String(body.code || "").trim();
    const newPin = String(body.new_pin || "");
    if (!/^\d{6}$/.test(code)) {
      return Response.json({ error: "Enter the 6-digit code" }, { status: 400 });
    }
    if (!/^\d{4}$/.test(newPin)) {
      return Response.json({ error: "New PIN must be 4 digits" }, { status: 400 });
    }

    const codes = await base44.entities.OtpCode.filter({ purpose: "pin_reset", consumed: false });
    if (!codes || !codes.length) {
      return Response.json({ error: "No active code. Request a new one." }, { status: 400 });
    }
    let rec = null;
    for (const c of codes) {
      if (c.context === user.id && (!rec || new Date(c.created_date) > new Date(rec.created_date))) rec = c;
    }
    if (!rec) {
      for (const c of codes) {
        if (!rec || new Date(c.created_date) > new Date(rec.created_date)) rec = c;
      }
    }
    if (new Date(rec.expires_at) < new Date()) {
      return Response.json({ error: "Code expired. Request a new one." }, { status: 400 });
    }
    if (Number(rec.attempts) >= 5) {
      return Response.json({ error: "Too many attempts. Request a new code." }, { status: 400 });
    }

    const hash = await sha256hex(code + rec.salt);
    if (hash !== rec.code_hash) {
      await base44.entities.OtpCode.update(rec.id, { attempts: Number(rec.attempts) + 1 });
      return Response.json({ error: "Incorrect code" }, { status: 400 });
    }

    await base44.entities.OtpCode.update(rec.id, { consumed: true });

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    await base44.entities.Account.update(accounts[0].id, { transaction_pin: newPin });

    await base44.entities.Notification.create({
      title: "Security Notice",
      message:
        "Your transaction PIN was changed. If this wasn't you, contact PayFlow support immediately.",
      notification_type: "voice_alert",
      read: false,
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}