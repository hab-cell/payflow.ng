import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { sha256hex } from "../../shared/wallet.ts";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const code = String(body.code || "").trim();
    const context = body.context || "";
    if (!/^\d{6}$/.test(code)) {
      return Response.json({ error: "Enter the 6-digit code" }, { status: 400 });
    }

    const codes = await base44.entities.OtpCode.filter({ purpose: "transfer", consumed: false });
    if (!codes || !codes.length) {
      return Response.json({ error: "No active code. Request a new one." }, { status: 400 });
    }

    let rec = null;
    for (const c of codes) {
      if (c.context === context) {
        if (!rec || new Date(c.created_date) > new Date(rec.created_date)) rec = c;
      }
    }
    if (!rec) {
      rec = codes[codes.length - 1];
      let latest = rec;
      for (const c of codes) {
        if (new Date(c.created_date) > new Date(latest.created_date)) latest = c;
      }
      rec = latest;
    }

    if (new Date(rec.expires_at) < new Date()) {
      return Response.json({ error: "Code expired. Request a new one." }, { status: 400 });
    }
    if (Number(rec.attempts) >= 5) {
      return Response.json({ error: "Too many attempts. Request a new code." }, { status: 400 });
    }

    const hash = await sha256hex(code + rec.salt);
    if (hash !== rec.code_hash) {
      await base44.entities.OtpCode.update(rec.id, { attempts: Number(rec.attempts) + 1 });
      return Response.json({ error: "Incorrect code" }, { status: 400 });
    }

    await base44.entities.OtpCode.update(rec.id, { consumed: true });
    return Response.json({ success: true, verified: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}