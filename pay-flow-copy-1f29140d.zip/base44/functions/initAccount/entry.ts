import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

function stripPin(acct: any) {
  if (!acct) return acct;
  const { transaction_pin, ...rest } = acct;
  return rest;
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    let body: any = {};
    try {
      body = await req.json();
    } catch (_e) {
      // no body (e.g. dashboard auto-init)
    }

    const existing = await base44.entities.Account.filter({ created_by_id: user.id });
    if (existing && existing.length) {
      return Response.json({ account: stripPin(existing[0]) });
    }

    // Don't auto-create with defaults — require identity + PIN (onboarding gate).
    if (!body.name || !body.pin) {
      return Response.json({ account: null, needs_setup: true });
    }

    const pin = String(body.pin);
    const name = body.name || "";
    const phone = body.phone || "";
    const dob = body.dob || "";

    // Generate a unique 10-digit NUBAN starting with 903
    let accountNumber = "";
    for (let i = 0; i < 25; i++) {
      accountNumber = "903" + String(Math.floor(Math.random() * 10000000)).padStart(7, "0");
      const dup = await base44.asServiceRole.entities.Account.filter({
        account_number: accountNumber,
      });
      if (!dup || !dup.length) break;
    }

    const account = await base44.entities.Account.create({
      account_number: accountNumber,
      account_type: "Savings",
      name,
      phone,
      dob,
      balance: 50000,
      available_balance: 50000,
      currency: "NGN",
      transaction_pin: pin,
    });

    await base44.entities.Notification.create({
      title: "Welcome to PayFlow! \uD83C\uDF89",
      message:
        "Your PayFlow digital wallet is ready. Your 10-digit Account Number is " +
        accountNumber +
        ".",
      notification_type: "credit",
      read: false,
    });

    return Response.json({ account: stripPin(account), created: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}