import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { genReference } from "../../shared/wallet.ts";

function detectBrand(num: string) {
  if (num.startsWith("4")) return "Visa";
  if (/^5[1-5]/.test(num) || /^2[2-7]/.test(num)) return "Mastercard";
  if (/^50|^(56|57|58|63|67)/.test(num)) return "Maestro";
  if (/^3[47]/.test(num)) return "Amex";
  return "Card";
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const amount = Number(body.amount);
    const cardNumber = String(body.card_number || "").replace(/\s/g, "");
    const expiry = String(body.expiry || "");
    const cvv = String(body.cvv || "");
    const nameOnCard = String(body.name_on_card || "").trim();

    if (!amount || amount <= 0) {
      return Response.json({ error: "Enter a valid amount" }, { status: 400 });
    }
    if (cardNumber.length < 12 || cardNumber.length > 19) {
      return Response.json({ error: "Enter a valid card number" }, { status: 400 });
    }
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      return Response.json({ error: "Enter expiry as MM/YY" }, { status: 400 });
    }
    if (!/^\d{3,4}$/.test(cvv)) {
      return Response.json({ error: "Enter a valid CVV" }, { status: 400 });
    }
    if (!nameOnCard) {
      return Response.json({ error: "Enter the name on the card" }, { status: 400 });
    }

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    const acct = accounts[0];

    const reference = genReference();
    const last4 = cardNumber.slice(-4);
    const brand = detectBrand(cardNumber);

    const tx = await base44.entities.Transaction.create({
      recipient_name: "Card top-up \u2022\u2022\u2022\u2022 " + last4,
      recipient_bank: brand,
      recipient_account_number: "",
      amount,
      currency: "NGN",
      description: "Add money from " + brand + " \u2022\u2022\u2022\u2022 " + last4,
      reference,
      status: "completed",
      transaction_type: "deposit",
      direction: "credit",
    });

    const newBalance = Number(acct.available_balance) + amount;
    await base44.entities.Account.update(acct.id, {
      balance: Number(acct.balance) + amount,
      available_balance: newBalance,
    });

    await base44.entities.Notification.create({
      title: "Wallet Top-up",
      message:
        "Your wallet was credited with \u20A6" +
        amount.toLocaleString("en-NG") +
        " from " +
        brand +
        " \u2022\u2022\u2022\u2022 " +
        last4 +
        ". Ref: " +
        reference,
      notification_type: "credit",
      read: false,
      transaction_id: tx.id,
    });

    return Response.json({ success: true, transaction: tx, reference, new_balance: newBalance });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}