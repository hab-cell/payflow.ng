import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const oldPin = String(body.old_pin || "");
    const newPin = String(body.new_pin || "");

    if (!/^\d{4}$/.test(oldPin)) {
      return Response.json({ error: "Enter your current 4-digit PIN" }, { status: 400 });
    }
    if (!/^\d{4}$/.test(newPin)) {
      return Response.json({ error: "New PIN must be 4 digits" }, { status: 400 });
    }
    if (oldPin === newPin) {
      return Response.json({ error: "New PIN must be different from the current PIN" }, { status: 400 });
    }

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    const acct = accounts[0];

    if (String(acct.transaction_pin) !== oldPin) {
      return Response.json({ error: "Current PIN is incorrect" }, { status: 400 });
    }

    await base44.entities.Account.update(acct.id, { transaction_pin: newPin });

    await base44.entities.Notification.create({
      title: "Security Notice",
      message:
        "Your transaction PIN was changed. If this wasn't you, contact PayFlow support immediately.",
      notification_type: "voice_alert",
      read: false,
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}