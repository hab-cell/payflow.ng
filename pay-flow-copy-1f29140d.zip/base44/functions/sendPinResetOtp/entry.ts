import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { genOtp, randomSalt, sha256hex } from "../../shared/wallet.ts";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const code = genOtp();
    const salt = randomSalt();
    const hash = await sha256hex(code + salt);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    await base44.entities.OtpCode.create({
      purpose: "pin_reset",
      code_hash: hash,
      salt,
      expires_at: expiresAt,
      attempts: 0,
      consumed: false,
      context: user.id,
    });

    const html =
      '<div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:auto;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #E2E8F0">' +
      '<div style="background:#008753;padding:24px 28px"><div style="color:#ffffff;font-size:22px;font-weight:700">PayFlow</div><div style="color:#E8F8F2;font-size:13px;margin-top:4px">PIN Reset Verification</div></div>' +
      '<div style="padding:28px">' +
      '<p style="color:#0f172a;font-size:15px;margin:0 0 16px">Your PayFlow verification code is:</p>' +
      '<div style="text-align:center;margin:18px 0"><div style="display:inline-block;background:#E8F8F2;color:#065F46;font-size:34px;font-weight:800;letter-spacing:10px;padding:14px 26px;border-radius:12px">' + code + '</div></div>' +
      '<p style="color:#475569;font-size:13px;margin:0 0 18px">Use this code to reset your transaction PIN. It expires in 10 minutes.</p>' +
      '<div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:10px;padding:12px 14px;color:#B91C1C;font-size:12.5px">Never share this code with anyone. PayFlow staff will never request your code or PIN.</div>' +
      '<p style="color:#94a3b8;font-size:11px;margin:18px 0 0;text-align:center">Deposits insured by NDIC \u2022 PayFlow Bank</p>' +
      "</div></div>";

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: user.email,
      subject: "Your PayFlow verification code is: " + code,
      html,
    });

    return Response.json({ success: true, expiresIn: 600 });
  } catch (error) {
    return Response.json(
      { error: "Unable to send the verification email right now. Please try again shortly." },
      { status: 500 }
    );
  }
}