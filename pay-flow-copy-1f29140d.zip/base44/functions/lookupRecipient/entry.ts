import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

const dummyNames = [
  "Chinedu Okafor", "Aisha Bello", "Tunde Williams", "Ngozi Eze", "Bola Ahmed",
  "Emeka Nwosu", "Fatima Ibrahim", "David Adeleke", "Grace Okon", "Yusuf Mohammed",
  "Chioma Obi", "Samuel Olatunji", "Hauwa Sani", "Daniel Eze", "Blessing Nwosu",
  "Kunle Adesanya", "Zainab Musa", "Femi Ogun", "Maryam Suleiman", "Obinna Kalu",
  "Adaeze Nnamdi", "Ridwan Abdulsalam", "Eunice Akpan", "Tope Bakare", "Halima Lawal",
];

function pickName(accountNumber: string) {
  let h = 0;
  for (let i = 0; i < accountNumber.length; i++) h = (h * 31 + accountNumber.charCodeAt(i)) >>> 0;
  return dummyNames[h % dummyNames.length];
}

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const bankName = body.bank_name;
    const accountNumber = String(body.account_number || "").trim();
    if (!/^\d{10}$/.test(accountNumber)) {
      return Response.json({ error: "Enter a valid 10-digit account number" }, { status: 400 });
    }

    // Real name for internal PayFlow accounts (looked up by account number)
    let accountName = "";
    let isPayFlow = false;
    try {
      const matches = await base44.asServiceRole.entities.Account.filter({
        account_number: accountNumber,
      });
      if (matches && matches.length && matches[0].name) {
        accountName = matches[0].name;
        isPayFlow = true;
      }
    } catch (_e) {
      // external account — fall back to a dummy name
    }

    if (!accountName) accountName = pickName(accountNumber);

    return Response.json({
      success: true,
      account_name: String(accountName).toUpperCase(),
      bank_name: bankName,
      account_number: accountNumber,
      is_payflow: isPayFlow,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}