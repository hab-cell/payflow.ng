import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    // Delete all wallet data owned by the user. Account + Transaction deletes
    // are admin-only under RLS, so run them as the service role.
    await base44.asServiceRole.entities.Transaction.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.Notification.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.Beneficiary.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.OtpCode.deleteMany({ created_by_id: user.id });
    await base44.asServiceRole.entities.Account.deleteMany({ created_by_id: user.id });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}