import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { genReference } from "../../shared/wallet.ts";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const recipient_name = body.recipient_name;
    const recipient_bank = body.recipient_bank;
    const recipient_account_number = String(body.recipient_account_number || "").trim();
    const amount = Number(body.amount);
    const description = body.description || "Transfer";
    const pin = String(body.pin || "");
    const idempotency_key = body.idempotency_key;

    if (!recipient_name || !recipient_bank || !recipient_account_number) {
      return Response.json({ error: "Recipient details are incomplete" }, { status: 400 });
    }
    if (!amount || amount <= 0) {
      return Response.json({ error: "Enter a valid amount" }, { status: 400 });
    }
    if (!pin) {
      return Response.json({ error: "Transaction PIN is required" }, { status: 400 });
    }

    if (idempotency_key) {
      const existing = await base44.entities.Transaction.filter({ reference: idempotency_key });
      if (existing && existing.length) {
        return Response.json({ success: true, transaction: existing[0], replayed: true });
      }
    }

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    const sender = accounts[0];

    if (String(sender.transaction_pin) !== pin) {
      return Response.json({ error: "Incorrect transaction PIN" }, { status: 400 });
    }
    if (Number(sender.available_balance) < amount) {
      return Response.json({ error: "Insufficient balance to complete this transfer." }, { status: 400 });
    }

    // Detect first-time recipient (no prior debit to this account)
    const priorTxs = await base44.entities.Transaction.filter({
      recipient_account_number,
      direction: "debit",
    });
    const isNewRecipient = !priorTxs || !priorTxs.length;

    const reference = idempotency_key || genReference();
    const tx = await base44.entities.Transaction.create({
      recipient_name,
      recipient_bank,
      recipient_account_number,
      amount,
      currency: "NGN",
      description,
      reference,
      status: "completed",
      transaction_type: "transfer",
      direction: "debit",
    });

    await base44.entities.Account.update(sender.id, {
      balance: Number(sender.balance) - amount,
      available_balance: Number(sender.available_balance) - amount,
    });

    // Credit recipient if internal PayFlow account
    try {
      const rec = await base44.asServiceRole.entities.Account.filter({
        account_number: recipient_account_number,
      });
      if (rec && rec.length && rec[0].id !== sender.id) {
        const r = rec[0];
        await base44.asServiceRole.entities.Account.update(r.id, {
          balance: Number(r.balance) + amount,
          available_balance: Number(r.available_balance) + amount,
        });
        await base44.asServiceRole.entities.Notification.create({
          title: "Credit Alert",
          message:
            "You received \u20A6" +
            amount.toLocaleString("en-NG") +
            " from " +
            (user.full_name || "a PayFlow user") +
            ". Ref: " +
            reference,
          notification_type: "credit",
          read: false,
          created_by_id: r.created_by_id,
        });
      }
    } catch (_e) {
      // external recipient; no internal credit
    }

    await base44.entities.Notification.create({
      title: "Debit Alert",
      message:
        "Transfer of \u20A6" +
        amount.toLocaleString("en-NG") +
        " to " +
        recipient_name +
        " completed. Ref: " +
        reference,
      notification_type: "debit",
      read: false,
      transaction_id: tx.id,
    });

    if (isNewRecipient) {
      try {
        const html =
          '<div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:auto;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #E2E8F0">' +
          '<div style="background:#008753;padding:24px 28px"><div style="color:#ffffff;font-size:22px;font-weight:700;letter-spacing:-0.3px">PayFlow</div><div style="color:#E8F8F2;font-size:13px;margin-top:4px">Transfer Receipt</div></div>' +
          '<div style="padding:28px">' +
          '<p style="color:#0f172a;font-size:15px;margin:0 0 16px">Hi ' + (user.full_name || "there") + ', your transfer was successful.</p>' +
          '<div style="background:#F8FAFC;border-radius:12px;padding:16px 18px;margin:16px 0">' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Amount</span><b style="color:#0f172a;font-size:15px">\u20A6' + amount.toLocaleString("en-NG") + '</b></div>' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Recipient</span><span style="color:#0f172a;font-size:13px">' + recipient_name + '</span></div>' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Bank</span><span style="color:#0f172a;font-size:13px">' + recipient_bank + '</span></div>' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Account</span><span style="color:#0f172a;font-size:13px">' + recipient_account_number + '</span></div>' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Reference</span><span style="color:#0f172a;font-size:13px">' + reference + '</span></div>' +
          '<div style="display:flex;justify-content:space-between;padding:6px 0"><span style="color:#64748b;font-size:13px">Status</span><span style="color:#008753;font-size:13px;font-weight:700">Completed</span></div>' +
          '</div>' +
          '<p style="color:#475569;font-size:13px;margin:8px 0 0">You sent this to a new recipient. If this was not you, contact PayFlow support immediately.</p>' +
          '<p style="color:#94a3b8;font-size:11px;margin:18px 0 0;text-align:center">Deposits insured by NDIC \u2022 PayFlow Bank</p>' +
          "</div></div>";
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: user.email,
          subject: "PayFlow: You sent \u20A6" + amount.toLocaleString("en-NG") + " to " + recipient_name,
          html,
        });
      } catch (_e) {
        // email is best-effort
      }
    }

    return Response.json({ success: true, transaction: tx, reference });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}