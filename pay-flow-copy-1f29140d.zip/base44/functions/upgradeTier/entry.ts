import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const target = Number(body.target_tier);
    const bvn = String(body.bvn || "").trim();
    const nin = String(body.nin || "").trim();
    const nokName = String(body.next_of_kin_name || "").trim();
    const nokPhone = String(body.next_of_kin_phone || "").trim();

    if (![2, 3].includes(target)) {
      return Response.json({ error: "Invalid target tier" }, { status: 400 });
    }
    if (!/^\d{11}$/.test(bvn)) {
      return Response.json({ error: "BVN must be 11 digits" }, { status: 400 });
    }
    if (!/^\d{11}$/.test(nin)) {
      return Response.json({ error: "NIN must be 11 digits" }, { status: 400 });
    }
    if (target === 3) {
      if (!nokName) return Response.json({ error: "Next of kin name is required for Tier 3" }, { status: 400 });
      if (!nokPhone) return Response.json({ error: "Next of kin phone is required for Tier 3" }, { status: 400 });
    }

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    const acct = accounts[0];
    const current = Number(acct.tier) || 1;
    if (target <= current) {
      return Response.json({ error: "You are already at or above this tier" }, { status: 400 });
    }
    if (target === 3 && current < 2) {
      return Response.json({ error: "Upgrade to Tier 2 first" }, { status: 400 });
    }

    const update: any = { tier: target, bvn, nin };
    if (target === 3) {
      update.next_of_kin_name = nokName;
      update.next_of_kin_phone = nokPhone;
    }
    await base44.entities.Account.update(acct.id, update);

    await base44.entities.Notification.create({
      title: "Account Upgraded",
      message:
        "Your PayFlow account was upgraded to Tier " +
        target +
        ". Your daily transfer limit has increased.",
      notification_type: "voice_alert",
      read: false,
    });

    return Response.json({ success: true, tier: target });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}