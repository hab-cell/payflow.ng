import { createClientFromRequest } from "npm:@base44/sdk@0.8.44";
import { genReference } from "../../shared/wallet.ts";

export default async function (req: Request) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const billType = body.bill_type; // "airtime" | "data" | "electricity"
    const provider = body.provider || "";
    const meterOrPhone = String(body.meter_or_phone || "").trim();
    const amount = Number(body.amount);
    const pin = String(body.pin || "");
    const idempotencyKey = body.idempotency_key;

    if (!billType || !amount || amount <= 0) {
      return Response.json({ error: "Enter the bill details and amount" }, { status: 400 });
    }
    if (!pin) {
      return Response.json({ error: "Transaction PIN is required" }, { status: 400 });
    }

    if (idempotencyKey) {
      const existing = await base44.entities.Transaction.filter({ reference: idempotencyKey });
      if (existing && existing.length) {
        return Response.json({ success: true, transaction: existing[0], replayed: true });
      }
    }

    const accounts = await base44.entities.Account.filter({ created_by_id: user.id });
    if (!accounts || !accounts.length) {
      return Response.json({ error: "Wallet not found" }, { status: 404 });
    }
    const sender = accounts[0];

    if (String(sender.transaction_pin) !== pin) {
      return Response.json({ error: "Incorrect transaction PIN" }, { status: 400 });
    }
    if (Number(sender.available_balance) < amount) {
      return Response.json({ error: "Insufficient balance to complete this payment." }, { status: 400 });
    }

    const reference = idempotencyKey || genReference();
    const label = billType.charAt(0).toUpperCase() + billType.slice(1);
    const tx = await base44.entities.Transaction.create({
      recipient_name: label + " \u2014 " + (meterOrPhone || provider || "PayFlow"),
      recipient_bank: provider || label,
      recipient_account_number: meterOrPhone || "",
      amount,
      currency: "NGN",
      description: label + " purchase" + (provider ? " (" + provider + ")" : ""),
      reference,
      status: "completed",
      transaction_type: billType === "airtime" || billType === "data" ? "airtime" : "bill",
      direction: "debit",
    });

    await base44.entities.Account.update(sender.id, {
      balance: Number(sender.balance) - amount,
      available_balance: Number(sender.available_balance) - amount,
    });

    await base44.entities.Notification.create({
      title: label + " Payment",
      message:
        "You paid \u20A6" +
        amount.toLocaleString("en-NG") +
        " for " +
        label.toLowerCase() +
        (provider ? " (" + provider + ")" : "") +
        ". Ref: " +
        reference,
      notification_type: "bill",
      read: false,
      transaction_id: tx.id,
    });

    return Response.json({ success: true, transaction: tx, reference });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}